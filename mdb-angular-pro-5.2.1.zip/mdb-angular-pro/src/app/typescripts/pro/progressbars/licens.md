https://github.com/valor-software/ngx-bootstrap/blob/development/LICENSE
https://github.com/jgluhov/ng2-spinning-preloader/blob/master/package.json
https://github.com/angular/material2/blob/master/LICENSE