export * from './chart-simple.component';
export * from './chart-smallpie.component';
export * from './chart-simple.module';
