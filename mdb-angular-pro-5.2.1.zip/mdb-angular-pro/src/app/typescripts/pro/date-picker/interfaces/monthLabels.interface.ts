export interface IMyMonthLabels {
  [month: number]: string;
}
