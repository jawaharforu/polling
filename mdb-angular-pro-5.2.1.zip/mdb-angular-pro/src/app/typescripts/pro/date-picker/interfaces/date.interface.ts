export interface IMyDate {
  year: number;
  month: number;
  day: number;
}
