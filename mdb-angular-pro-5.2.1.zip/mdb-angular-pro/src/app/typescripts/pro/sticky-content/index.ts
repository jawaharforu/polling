import { MdbStickyDirective } from './sticky-content.directive';
import { MdbStickyModule } from './sticky-content.module';
export { MdbStickyDirective, MdbStickyModule };
